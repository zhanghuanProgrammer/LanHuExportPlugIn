
//------------------- 全局变量 模块 -------------------

function isIOS() {
    return cur_lan == Develop_Lan_ios;
}

function isANDROID() {
    return cur_lan == Develop_Lan_android;
}

function isFLUTTER() {
    return cur_lan == Develop_Lan_flutter;
}

function isSWIFT() {
    return cur_lan == Develop_Lan_swift;
}

//------------------- 全局变量 模块 -------------------
