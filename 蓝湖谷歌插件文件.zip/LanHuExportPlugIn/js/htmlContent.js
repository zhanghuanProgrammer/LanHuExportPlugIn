

function getHtmlContent() {
    var string =
        "<div id='lanhu_plug_in' class=\"lanhu_plug_in plus-in-flex-row\" style=\"z-index:999900; background: #ffffff;display:none;width: calc(100vw - 60px);\">\n" +
        "   <div class=\"page_plug_in plus-in-flex-col\">\n" +
        "   </div>\n"+
        "</div>\n"+
        "<img id='lanhu_select' class='lanhu_select' style=\"display:none;width: 30px;height: 30px;position: fixed;z-index:999901; background: white;\" src='"+software_set_img()+"'>";
    return string;
}